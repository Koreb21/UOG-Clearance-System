package com.uog.clearance.clearance.repository;

import com.uog.clearance.clearance.model.ClearanceCheck;
import com.uog.clearance.clearance.model.ClearanceCheckCode;
import com.uog.clearance.clearance.model.ClearanceCheckStatus;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ClearanceCheckRepository extends JpaRepository<ClearanceCheck, String> {

    List<ClearanceCheck> findByClearanceRequestId(String clearanceRequestId);

    Optional<ClearanceCheck> findByClearanceRequestIdAndCheckCode(String clearanceRequestId, ClearanceCheckCode checkCode);

    List<ClearanceCheck> findByCampusIdAndCheckCodeAndStatusNot(String campusId,
                                                                ClearanceCheckCode checkCode,
                                                                ClearanceCheckStatus status);

    List<ClearanceCheck> findByCampusId(String campusId);
}
